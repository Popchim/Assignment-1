package com.example.myapplication;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.widget.LinearLayout;
import android.widget.ToggleButton;
import android.view.LayoutInflater;

import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

        }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Intent inte= getIntent();
        for (int i=1; i<6;++i){
            ViewGroup viewgr= new LinearLayout(this);
            ViewGroup omni = findViewById(R.id.omni);
            omni.addView(viewgr);
            for(int j=0;j<4;++j) {
                ToggleButton togbut;
                togbut = (ToggleButton) LayoutInflater.from(this).inflate(R.layout.sample1, null, false);
                viewgr.addView(togbut);
                ToggleButton toggle = (ToggleButton) findViewById(R.id.tog);
                toggle.setId(i * 100 + j);
                toggle.setTextOff(Integer.toString(toggle.getId()));
            }
        }
        }

}
