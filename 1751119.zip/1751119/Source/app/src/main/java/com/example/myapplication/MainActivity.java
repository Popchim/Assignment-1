package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewGroupCompat;

import android.os.PersistableBundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import java.lang.Object;
import android.widget.TextView;
import java.lang.String;
import java.lang.Integer;
import android.widget.ToggleButton;
import android.widget.Button;
import android.widget.CompoundButton;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;



import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    public static final String message="";
    public static final String message1="";
    public static final String message2="";
    ViewGroup con1;
    int save=0;
    int save1=0;
    int save2=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        con1=findViewById(R.id.con1);
        for(int i=1;i<4;++i) {
            View view;
            view = LayoutInflater.from(this).inflate(R.layout.sample, null);
            con1.addView(view);
            ViewGroup viewgroup= findViewById(R.id.lin);
            viewgroup.setId(i);
            for (int j=0;j<7;++j) {
                ToggleButton view1 = (ToggleButton)LayoutInflater.from(this).inflate(R.layout.sample1,null,false);
                view1.setMinimumWidth(300);
                viewgroup.addView(view1);
                ToggleButton toggle=(ToggleButton)findViewById(R.id.tog);
                toggle.setId(i*100+j);
                toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (isChecked) {
                            for(int l=0;l<7;++l){
                                int pmt=((buttonView.getId())/100)*100+l;
                                ToggleButton tm=(ToggleButton)findViewById(pmt);
                                if (pmt!=buttonView.getId()) tm.setChecked(false);
                                if(buttonView.isChecked()) {
                                    if ((buttonView.getId()) / 100 == 1) save = buttonView.getId();
                                    if ((buttonView.getId()) / 100 == 2) save1 = buttonView.getId();
                                    if ((buttonView.getId()) / 100 == 3) save2 = buttonView.getId();
                                }
                                else {
                                    save=0;
                                    save1=0;
                                    save2=0;
                                }
                            }
                        } else {
                        }
                    }
                });
            }
        }
        if(savedInstanceState!=null){
            ((ToggleButton)findViewById(savedInstanceState.getInt(message))).setChecked(true);
            ((ToggleButton)findViewById(savedInstanceState.getInt(message1))).setChecked(true);
            ((ToggleButton)findViewById(savedInstanceState.getInt(message2))).setChecked(true);
        }
    }
    void chooseSeat(View v){
        Intent intent= new Intent(this, Main2Activity.class);
        intent.putExtra(message,save);
        intent.putExtra(message1,save1);
        intent.putExtra(message2,save2);
        startActivity(intent);
    }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        outState.putInt(message, save);
        outState.putInt(message1, save1);
        outState.putInt(message2, save2);
        super.onSaveInstanceState(outState, outPersistentState);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        int x=100;
        ((ToggleButton)findViewById(x)).setTextOff("Hello");
        Bundle bundle2 = (getIntent()).getExtras();
        ((ToggleButton)findViewById(bundle2.getInt(message))).setTextOff("Hello");
        ((ToggleButton)findViewById(bundle2.getInt(message1))).setChecked(true);
        ((ToggleButton)findViewById(bundle2.getInt(message2))).setChecked(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        Bundle bundle1 = new Bundle();
        bundle1.putInt(message,save);
        bundle1.putInt(message1,save1);
        bundle1.putInt(message2,save2);
        (getIntent()).putExtras(bundle1);
    }
}
